from window_interface import *

# small: 600
# middle: 800
# big: 1000

def main():
    window_width = 800
    size_grid = 25
    main_interface_window(window_width, size_grid)

if __name__ == '__main__':
    main()