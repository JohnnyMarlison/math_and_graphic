Установка необходимых библиотек: 
pip install -r ./requirements.txt

Запуск программы:
python3 main.py
