import numpy as np

# создание матрицы с помощью генератора случайных чисел


def MakeMatr(n, a, b):
    Matr = (b - a) * np.random.random(size=(n, n)) + a
    return Matr


# вывод матрицы на экран
def PrintMatr(Matr):
    (nRow, nCol) = Matr.shape
    for Row in range(nRow):
        for Col in range(nCol):
            print("{0: 7.0f}".format(Matr[Row][Col]), end=" ")
        print()
    print()


# меняем местами столбцы с минимальным и максимальным элементом
def swape_cols(arr, frm, to):
    arr[:, [frm, to]] = arr[:, [to, frm]]